#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#include "config/environment.h"
#include "engineering/connector.h"
#include "engineering/inout.h"
#include "controller/loginController.h"
#include "view/viewUtils.h"