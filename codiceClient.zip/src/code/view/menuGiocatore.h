#include "../engineering/inout.h"
#include "viewUtils.h"


int promptMenuGiocatore();

int promptMenuStanza();