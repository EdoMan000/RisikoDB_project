#include "../engineering/inout.h"
#include "viewUtils.h"

int promptMenuModeratore();