#include "../engineering/inout.h"
#include "../database/dbUtils.h"
#include "../database/db.h"
#include "../view/viewUtils.h"
#include "../view/menuModeratore.h"

void moderatoreController(char *username);