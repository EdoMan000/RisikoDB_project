#pragma once

#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "../view/loginAndRegistrationView.h"
#include "../database/db.h"
#include "../database/dbUtils.h"
#include "../engineering/inout.h"
#include "../view/viewUtils.h"
#include "../model/credentials.h"
#include "giocatoreController.h"
#include "moderatoreController.h"
#include <stdbool.h>


void loginController() ;
