#include "../engineering/inout.h"
#include "../database/dbUtils.h"
#include "../database/db.h"
#include "../view/viewUtils.h"
#include "../view/menuGiocatore.h"

void giocatoreController(char* username);